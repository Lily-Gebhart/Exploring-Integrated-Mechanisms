#!/usr/bin/env python3

"""A small library for dealing with Google n-gram data.

Google n-gram data is large and not well organized. This library attempts to
make it easier to work with, with an emphasis on reducing memory use. It uses
several tricks to accomplish this:

* FIXME cached data
* FIXME index file
* FIXME binary search
"""

import re
from collections import defaultdict, Counter
from mmap import mmap
from pathlib import Path
from shutil import rmtree
from tempfile import mkdtemp
from time import sleep
from zipfile import ZipFile
from typing import Union, Iterable, Callable

import requests # pylint: disable = import-error

PathStr = Union[str, Path]

NEWLINE_BYTE = '\n'.encode('utf-8')


class GoogleNGram:

    """Manager for Google n-gram data."""

    NUM_PARTS = {
        1: 10,
        #2: 100,
        2: 10, # Tester with only a limited number of ngrams
        3: 200,
        4: 400,
        5: 800,
    }

    def __init__(self, cache_dir=None):
        # type: (PathStr) -> None
        """Initialize GoogleNGram."""
        if cache_dir is None:
            self.keep_cache = False
            cache_dir = mkdtemp()
        else:
            self.keep_cache = True
        self.cache_dir = Path(cache_dir).expanduser().resolve()
        self.cache_dir.mkdir(exist_ok=True)
        assert self.cache_dir.is_dir()

    def __del__(self):
        # type: () -> None
        """Clean up the n-gram data cache directory on delete."""
        if not self.keep_cache:
            rmtree(self.cache_dir)

    def get_data_url(self, n, part):
        # type: (int, int) -> str
        """Determine the URL for a Google n-gram zipfile."""
        return f'http://storage.googleapis.com/books/ngrams/books/googlebooks-eng-1M-{n}gram-20090715-{part}.csv.zip'

    def get_data_path(self, n, part):
        # type: (int, int) -> Path
        """Determine the path of a Google n-gram data file."""
        return self.cache_dir / f'{n}gram-{part}.csv'

    def get_index_path(self, n, part=None):
        # type: (int, int) -> Path
        """Determine the path of an indexfile."""
        if part is None:
            return self.cache_dir / f'{n}gram-index'
        else:
            return self.cache_dir / f'{n}gram-index-{part}'

    def real_download_zipfile(self, url, path):
        # type: (str, Path) -> None
        """Download a Google n-gram zipfile."""
        # set URL and path variables
        filename = url.split('/')[-1]
        zip_path = self.cache_dir / filename
        csv_path = self.cache_dir / zip_path.stem
        # download the file without first keeping it in memory
        # taken from https://stackoverflow.com/a/16696317
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with zip_path.open('wb') as fd:
                for chunk in r.iter_content(chunk_size=8192):
                    fd.write(chunk)
        # let file writing finish
        sleep(1)
        # unzip the file
        with ZipFile(zip_path, 'r') as zip_file:
            zip_file.extractall(self.cache_dir)
        zip_path.unlink()
        # let file writing finish
        sleep(1)
        # rename to final path/name
        csv_path.rename(path)

    def download_data(self, n, part):
        # type: (int, int) -> Path
        """Download a Google n-gram zipfile, if not cached."""
        data_path = self.get_data_path(n, part)
        if not data_path.exists():
            print(f'downloading {n}-gram part {part}...', end='', flush=True)
            self.real_download_zipfile(self.get_data_url(n, part), data_path)
            print('done', flush=True)
        return data_path

    def build_index(self, n):
        # type: (int) -> None
        """Build the index for n-grams."""
        index_path = self.get_index_path(n)
        # do no reindex if the index already exists and is newer than the data files
        if index_path.exists():
            modified_time = index_path.stat().st_mtime
            index_newer = all(
                self.get_data_path(n, part).stat().st_mtime < modified_time
                for part in range(GoogleNGram.NUM_PARTS[n])
            )
            if index_newer:
                return
        # build the sub-indices
        for part in range(GoogleNGram.NUM_PARTS[n]):
            csv_path = self.download_data(n, part)
            print(f'processing {n}-gram part {part}...', end='', flush=True)
            with csv_path.open(errors='ignore') as fd:
                ngrams = set(
                    line.strip().split('\t', maxsplit=1)[0]
                    for line in fd
                )
            ngrams = set(ngram for ngram in ngrams if GoogleNGram._is_valid_ngram(ngram))
            part_index_path = self.get_index_path(n, part)
            with part_index_path.open('a') as fd:
                for ngram in sorted(ngrams, key=(lambda s: (s.upper(), s))):
                    fd.write(f'{ngram}\n')
            print('done', flush=True)
        # merge the indices
        fds = []
        lines = [] # FIXME rename
        for part in range(GoogleNGram.NUM_PARTS[n]):
            fd = self.get_index_path(n, part).open()
            ngram = fd.readline().strip()
            fds.append(fd)
            lines.append((ngram.upper(), ngram, part, fd))
        lines = sorted(lines)
        with index_path.open('w') as index_fd:
            while lines:
                _, ngram, part, fd = lines.pop(0)
                index_fd.write(f'{ngram}\t{part}\n')
                ngram = fd.readline().strip()
                if not ngram:
                    continue
                lines.append((ngram.upper(), ngram, part, fd))
                lines = sorted(lines)
        # clean up by closing and deleting the sub-indices
        for fd in fds:
            fd.close()
        for part in range(GoogleNGram.NUM_PARTS[n]):
            self.get_index_path(n, part).unlink()

    def locate_ngram_variants(self, n, ngram):
        # type: (int, str) -> dict[int, set[str]]
        """Locate the data files of variants of an n-gram."""
        ngram = ngram.lower()
        index_path = self.get_index_path(n)
        variants = defaultdict(set)
        # pylint: disable = unnecessary-lambda-assignment
        key_fn = (lambda line: line.split('\t', maxsplit=1)[0].upper())
        for line in binary_search_file(index_path, ngram.upper(), key_fn):
            variant, part = line.strip().split('\t')
            variants[int(part)].add(variant)
        return variants

    def get_ngram_counts(self, ngram, merge_variants=True):
        # type: (str, bool) -> dict[str, int]
        """Get the count of an n-gram.

        If merge_variants is True, the counts of all capitalization variants are
        added together. Otherwise, each variant will be a separate key in the
        dictionary.
        """
        n = len(ngram.split())
        self.build_index(n)
        year_results = {} # type: dict[str, tuple[int, int]]
        # pylint: disable = unnecessary-lambda-assignment
        key_fn = (lambda line: line.strip().split('\t', maxsplit=1)[0].lstrip('"'))
        for part, variants in self.locate_ngram_variants(n, ngram).items():
            data_path = self.get_data_path(n, part)
            for variant in variants:
                for line in binary_search_file(data_path, variant, key_fn):
                    candidate, year_str, count_str, *_ = line.strip().split('\t')
                    year = int(year_str)
                    count = int(count_str)
                    should_update = (
                        candidate not in year_results
                        or year_results[candidate] < (year, count)
                    )
                    if should_update:
                        year_results[candidate] = (year, count)
        if not year_results:
            return {ngram: 0}
        max_year = max(year for year, _ in year_results.values())
        results = {
            variant: count
            for variant, (year, count) in year_results.items()
            if year == max_year
        }
        if merge_variants:
            return {ngram: sum(results.values())}
        else:
            return results

    def get_conditional_probability(self, base, target):
        # type: (str, str) -> float
        """Calculate the conditional probability of two words."""
        base_target = f'{base} {target}'
        target_base = f'{target} {base}'
        if self.get_ngram_counts(base)[base] == 0:
            return 0
        return (
            self.get_ngram_counts(base_target)[base_target]
            + self.get_ngram_counts(target_base)[target_base]
        ) / self.get_ngram_counts(base)[base]

    def get_max_probability(self, base):
        # type: (str) -> list[tuple[str, int]]
        """Get a list of the most co-occurring words (and their counts)."""
        index_path = self.get_index_path(2)
        variants = defaultdict(set)
        # pylint: disable = unnecessary-lambda-assignment
        key_fn = (lambda line: line.split(' ', maxsplit=1)[0].upper())
        for line in binary_search_file(index_path, base.upper(), key_fn):
            ngram, part = line.strip().split('\t')
            variants[int(part)].add(ngram)
        probabilities = Counter()
        for part, ngram_variants in variants.items():
            for ngram in ngram_variants:
                target = ngram.split()[1]
                base_target = f'{base} {target}'
                target_base = f'{target} {base}'
                probabilities[target.upper()] += (
                    self.get_ngram_counts(base_target)[base_target]
                    + self.get_ngram_counts(target_base)[target_base]
                )
        return probabilities.most_common()

    @staticmethod
    def _is_valid_ngram(ngram):
        # type: (str) -> bool
        """Check if an n-gram is valid (does not contains symbols)."""
        return bool(re.fullmatch("[A-Za-z' -]+", ngram))


def _binary_search_memory_map(memory_map, needle, key_fn=None):
    # type: (mmap, str, Callable[[str], str]) -> int
    """Binary search for the first line where key_fn(line) >= needle."""
    left = 0
    right = memory_map.size()
    while left < right:
        # calculate the middle
        middle = int(left + (right - left) / 2)
        # get the line that includes the middle
        line_start = memory_map.rfind(NEWLINE_BYTE, 0, middle)
        line_start += 1
        line_end = memory_map.find(NEWLINE_BYTE, middle) + 1
        line = memory_map[line_start:line_end - 1].decode('utf-8')
        # restrict the search range
        if needle <= key_fn(line):
            right = line_start
        else:
            left = line_end
    return right


def binary_search_file(filepath, needle, key_fn=None):
    # type: (Path, str, Callable[[str], str]) -> Iterable[str]
    """Generator of lines of the file where key_fn(line) == needle."""
    if key_fn is None:
        key_fn = (lambda s: s) # pylint: disable = superfluous-parens, unnecessary-lambda-assignment
    with Path(filepath).expanduser().resolve().open('r+b') as fd:
        memory_map = mmap(fd.fileno(), 0)
        index = _binary_search_memory_map(memory_map, needle, key_fn)
        file_size = memory_map.size()
        while index < file_size:
            line_end = memory_map.find(NEWLINE_BYTE, index)
            line = memory_map[index:line_end].decode('utf-8')
            if key_fn(line) != needle:
                break
            yield line
            index = line_end + 1


def main():
    # type: () -> None
    """Entry point for testing."""
    ngrams = GoogleNGram('~/ngram')
    #assert ngrams.get_ngram_counts('lily')
    #print(ngrams.get_ngram_counts('lily'))
    #assert ngrams.get_ngram_counts('fit all')
    #print(ngrams.get_ngram_counts('see resource'))
    #print(ngrams.get_ngram_counts('resource see'))
    #print(ngrams.get_conditional_probability('see', 'resource'))
    #print(ngrams.get_conditional_probability('resource', 'see'))
    #print(ngrams.get_max_probability('fit'))


if __name__ == '__main__':
    main()
